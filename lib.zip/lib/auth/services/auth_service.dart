import 'package:firebase_auth/firebase_auth.dart';

class AuthService {



  FirebaseAuth auth = FirebaseAuth.instance;





  // Sign Up 




  Future<void> signUp(String userEmail, String userPassword)async{
    await auth.createUserWithEmailAndPassword(email: userEmail, password: userPassword);

  }


  // Login 

  Future<void> login(String userEmail, String userPassword)async{
    await auth.signInWithEmailAndPassword(email: userEmail, password: userPassword);
  }


  // forget Password



  // Logout
  
}